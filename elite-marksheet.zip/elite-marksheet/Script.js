function getResult() {
  var roll = document.getElementById("roll").value.trim();
  if(!roll){
    document.getElementById("result").innerHTML = "🔹 Enter Roll Number!";
    return;
  }

  // ⚠️ Replace YOUR_WEB_APP_URL with your Apps Script Web App URL
  var url = "YOUR_WEB_APP_URL/exec?roll=" + encodeURIComponent(roll) + "&callback=showResult";

  var script = document.createElement("script");
  script.src = url;
  document.body.appendChild(script);
}

function showResult(data){
  if(data.error){
    document.getElementById("result").innerHTML = "❌ " + data.error;
    return;
  }

  var html = "<h3>Marksheet — Roll: " + data.roll + "</h3>";
  html += "<table border='1' style='margin:auto; text-align:left;'>";
  html += "<tr><th>Subject</th><th>Marks</th></tr>";
  html += "<tr><td>Hindi</td><td>"+data.hindi+"</td></tr>";
  html += "<tr><td>English</td><td>"+data.english+"</td></tr>";
  html += "<tr><td>Math</td><td>"+data.math+"</td></tr>";
  html += "<tr><td>Science</td><td>"+data.science+"</td></tr>";
  html += "<tr><td>Social</td><td>"+data.social+"</td></tr>";
  html += "<tr><th>Total</th><th>"+data.total+"</th></tr>";
  html += "</table>";

  document.getElementById("result").innerHTML = html;
}