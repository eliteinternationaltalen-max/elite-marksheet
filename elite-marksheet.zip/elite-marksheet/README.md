# Elite Marksheet 2026

Live student marksheet checker using Google Sheets & Apps Script.

## How to Use

1. Enter your Roll Number in the input box.
2. Click **Check Result**.
3. Full marksheet will display dynamically.

## Setup for GitHub Pages

1. Push `index.html`, `script.js`, `README.md`, `.gitignore` to repo.
2. Go to **Settings → Pages**.
3. Source: Branch `main`, Folder `/root`.
4. Save → Your live URL: `https://eliteinternationaltalen-max.github.io/elite-marksheet/`